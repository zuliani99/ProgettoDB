from aeroporto import app

if __name__ == '__main__': # Condizione per far partirte l'applicazione senza flask run e sempre in dubug mode
    app.run(debug=True)

